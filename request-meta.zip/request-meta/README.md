httpecho
========


## 功能（语言不限）
- 监听本地端口
- 监听router（可以自行定义）
- 将收到的请求的Method,Headers,Body等信息浏览器中打印出来

## extra（实现上述能力后可以额外考虑更多）

- 打印格式
- 日志记录
- 等等

## 关于作业提交

- 希望除了代码，还能附带有作业笔记（Readme）
- 希望在code.teambition.com中建立对应每个人的作业repo，然后提交url。


## QuickStart 

```
pip3 install requirements.txt

python server.py
```

打开浏览器， 访问 http://127.0.0.1:5042/


